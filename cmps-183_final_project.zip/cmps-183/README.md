# cmps-183
Classwork in the UC Santa Cruz web development capstone course, using web2py

The master branch is the main class project, a group effort over the entire quarter. The other branches are the homework assignments.
